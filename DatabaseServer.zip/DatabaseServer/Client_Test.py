import os
import sys
import json
import time
import socket

if __name__ == '__main__':
    command1 = dict(func='select_users')
    command2 = dict(func='delete_invite_by_key_guid', key_guid='abcdefghijklmnopqrstuvwxyz654321abcdefghijklmnopqrstuvwxyz111111')
    command3 = dict(func='insert_invite',
                    invites=[dict(key_guid='2bcdefghijklmnopqrstuvwxyz654321abcdefghijklmnopqrstuvwxyz111111',
                                  guid='2bcdefghijklmnopqrstuvwxyz654321',
                                  id='kiara',
                                  invite_guid='abcdefghijklmnopqrstuvwxyz111111',
                                  invite_id='kris')])

    command_list = []
    command_list.append(command1)
    # command_list.append(command2)

    ip, port = '127.0.0.1', 10010

    # if len(sys.argv) == 3:
    #     ip, port = sys.argv[1], int(sys.argv[2])
    # else:
    #     print('Usage: python3 {} IP PORT'.format(sys.argv[0]))
    for command in command_list:

        response = None

        # Set up the socket to connect to the server
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((ip, port))
            s.send(json.dumps(command).encode())
            response = json.loads(s.recv(4096).decode())
            s.close()
        except Exception as e:
            print('[ERROR] Socket set up fail:', e)

        print(response)
        if response['data'][0] == True:
            print('yes')

