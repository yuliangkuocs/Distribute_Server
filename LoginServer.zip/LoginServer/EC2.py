import boto3
import time


class EC2:
    def __init__(self):
        self.ec2_resource = boto3.resource('ec2')
        self.main_instance_id = 'i-07761709b974dff68'
        self.image_id = 'ami-0ac019f4fcb7cb7e6'
        self.security_group_id = 'sg-02f32258cb75a2d64'
        self.instance_type = 't2.micro'
        self.instance_ids = self._get_instance_ids()

    def _get_instance_ids(self):
        return [instance.id for instance in self.ec2_resource.instances.filter(
            Filters=[
                {
                    'Name': 'instance-state-name',
                    'Values': [
                        'running', 'pending'
                    ]
                },
            ]
        )]

    def _check_instance_is_running(self, instance_id):
        t_start = time.time()

        while True:
            print('[EC2] Check instance {} whether running'.format(instance_id))
            if time.time() - t_start > 300:
                return None, None

            instances = self.ec2_resource.instances.filter(Filters=[
                {
                    'Name': 'instance-state-name',
                    'Values': [
                        'running'
                    ]
                },
            ])
            instance = None

            for i in instances:
                if i.id == instance_id:
                    instance = i
                    break

            if not instance:
                time.sleep(5)

            else:
                break

        print('instance (id = {}, ip = {}) is running'.format(instance.id, instance.public_ip_address))
        return instance.id, instance.public_ip_address

    def create_instance(self):
        self.ec2_resource.create_instances(
            ImageId=self.image_id,
            MinCount=1,
            MaxCount=1,
            SecurityGroupIds=[self.security_group_id],
            InstanceType=self.instance_type,
            KeyName='login_key'
        )
        print('[EC2] Create instance success')
        new_instance_ids = self._get_instance_ids()
        new_instance_id = [id for id in new_instance_ids if id not in self.instance_ids][0]

        if new_instance_id:
            self.instance_ids.append(new_instance_id)
        else:
            print('[ERROR] There is no new instance id created')

        return self._check_instance_is_running(new_instance_id)

    def terminate_instance(self, instance_id):
        if instance_id == self.main_instance_id:
            print('[EC2] You Cannot terminate your main instance')
            return

        instances = self.ec2_resource.instances.filter(
            InstanceIds=[
                instance_id,
            ],
        )
        for instance in instances:
            instance.terminate()

            try:
                self.instance_ids.remove(instance_id)
            except Exception as err:
                print('[ERROR] Remove instance id {0} fail:'.format(instance_id), err)

    def list_instances(self, isRunning=False):
        print('\nThere are your instances:')

        if isRunning:
            instances = self.ec2_resource.instances.filter(Filters=[
                {
                    'Name': 'instance-state-name',
                    'Values': [
                        'running', 'pending'
                    ]
                },
            ])
        else:
            instances = self.ec2_resource.instances.all()

        for instance in instances:
            print('id: {0}, type: {1}, state: {2}'.format(instance.id, instance.instance_type, instance.state['Name']))

